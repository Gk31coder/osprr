name=-1
city=-1
code=-1
mobno=-1
n=0
ch=0
while [ $ch -ne 7 ]
do
 echo -e "\n=== Address Book Menu ==="
 echo "1. Create New Address Book File"
 echo "2. View Address Book"
 echo "3. Insert New Record"
 echo "4. Delete a Record"
 echo "5. Search a Record"
 echo "6. Modify a Record"
 echo "7. Exit"
 echo -n "Enter your choice: "
 read ch
 case $ch in
 1) # Create Database
 echo -n "Enter file name : "
 read fname
 touch "$fname"
 echo "Enter the number of records to be entered in file $fname:"
 read n
 i=$n
 while [ $i -gt 0 ]
 do
 echo -n "Enter name:"
 read name
 echo -n "Enter City:"
 read city
 echo -n "Enter Zipcode:"
 read code
 echo -n "Enter Mobile no.:"
 read mobno
 echo "$name|$city|$code|$mobno" >> "$fname"
 echo "Your data is stored in the file."
 i=$((i-1))
 done
 ;;

 2) # View Database
 if [ -f "$fname" ]; then
 cat "$fname"
 else
 echo -n "File not found. Create database first!"
 fi
 ;;

 3) # Insert Record
 echo -n "Enter name:"
 read name
 echo "Enter City:"
 read city
 echo "Enter Zipcode:"
 read code
 echo "Enter Mobile no.:"
 read mobno
 echo "$name|$city|$code|$mobno" >> "$fname"
 echo "Record inserted successfully."
 ;;

 4) # Delete Record
 echo -n "Enter the name of the record to be deleted:"
 read no
 if grep -w "$no" "$fname" > /dev/null; then
 grep -w -v "$no" "$fname" > temp
 mv temp "$fname"
 echo "Record deleted successfully!"
 else
 echo "Record not found."
 fi
 ;;
 5) # Search Record
 echo -n "Enter the name of the record to be searched:"
 read no
 if grep -w "$no" "$fname" > /dev/null; then
 grep -w "$no" "$fname"
 else
 echo "Record not found."
 fi
 ;;

 6) # Modify Record
 echo -n "Enter the name of the record to be modified:"
 read name
 if grep -w "$name" "$fname" > /dev/null; then
 grep -w -v "$name" "$fname" > temp
 echo -e "Enter new name:"
 read name
 echo "Enter new City:"
 read city
 echo "Enter new Zipcode:"
 read code
 echo "Enter new Mobile no.:"
 read mobno
 echo "$name|$city|$code|$mobno" >> temp
 mv temp "$fname"
 echo "Record modified successfully."
 else
 echo "Record not found!"
 fi
 ;;

 7) # Exit
 echo -n "Exiting the program. Goodbye!"
 ;;

 *) echo -n "Invalid choice. Please enter a number between 1 and 7."
 ;;
 esac
done
