#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void bubble_sort(int, int[]);

int main() {
    int arr[30];
    int size, i, j = 0;
    pid_t pid;
    int status;

    // Get input
    printf("Enter total number of elements : ");
    scanf("%d", &size);

    // Clear the newline character left by scanf
    getchar();

    // Reading the array elements as a single line of input
    printf("Enter the array\n");
    char str1[100], str2[30] = "";
    int k = 0;
    fgets(str1, sizeof(str1), stdin);  // Read input as string

    // Parsing input string into integers
    for (i = 0; i < strlen(str1); i++) {
        if (str1[i] != ' ' && str1[i] != '\n') {
            str2[k++] = str1[i];  // Collect characters
        } else if (k > 0) {  // When we encounter space or newline, process the number
            str2[k] = '\0';  // Null-terminate the number string
            arr[j] = atoi(str2);  // Convert string to integer and store in array
            printf("%d removed from char array\n", arr[j]);
            printf("%d putted in int array\n", arr[j]);
            j++;
            k = 0;  // Reset for next number
        }
    }
    
    // Handle last number if any
    if (k > 0) {
        str2[k] = '\0';
        arr[j] = atoi(str2);
        printf("%d removed from char array\n", arr[j]);
        printf("%d putted in int array\n", arr[j]);
        j++;
    }

    // Print number of elements (j) read
    printf("value of j is: %d\n", j);

    // Bubble sort the array
    bubble_sort(size, arr);
    
    // Print the sorted array
    printf("after sorting\n");
    for (i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Prepare arguments for execve (pass sorted array to binary.c)
    char *args[size + 2];  // Extra space for program name and NULL terminator
    args[0] = "./binary";  // Name of child program
    for (i = 0; i < size; i++) {
        args[i + 1] = malloc(10);  // Allocate space for each number
        sprintf(args[i + 1], "%d", arr[i]);  // Convert int to string and store
    }
    args[size + 1] = NULL;  // Null-terminate the arguments

    // Fork and execute binary search in child process
    pid = fork();
    if (pid > 0) {
        wait(&status);  // Parent waits for child to finish
    } else if (pid == 0) {
        // Execute binary search in child process
        execve(args[0], args, NULL);
        perror("execve failed");
        exit(1);
    }

    // Free allocated memory for args after fork
    for (i = 0; i < size; i++) {
        free(args[i + 1]);  // Free each dynamically allocated string
    }

    return 0;
}

// Bubble sort function
void bubble_sort(int size, int arr[]) {
    int i, j, temp;
    for (i = 0; i < size - 1; i++) {
        for (j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
/*
output:-
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc binary.c -o binary
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc bubble.c -o bubble
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./bubble
Enter total number of elements : 5
Enter the array
12 34 7 29 50
12 removed from char array
12 putted in int array
34 removed from char array
34 putted in int array
7 removed from char array
7 putted in int array
29 removed from char array
29 putted in int array
50 removed from char array
50 putted in int array
value of j is: 5
after sorting
7 12 29 34 50 
after sorting
7 12 29 34 50 
Enter the element to be searched: 29

Element 29 found at 3 location
*/
