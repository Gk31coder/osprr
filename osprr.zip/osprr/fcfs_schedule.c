#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Process {
    int pid;
    int at;
    int bt;
    int ct;
    int tat;
    int wt;
};

// Sort by Arrival Time
void sortByArrival(struct Process proc[], int n) {
    int i, j;
    struct Process temp;
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if (proc[i].at > proc[j].at) {
                temp = proc[i];
                proc[i] = proc[j];
                proc[j] = temp;
            }
        }
    }
}

// Calculate Completion, TAT, WT
void findTimes(struct Process proc[], int n) {
    int i;
    proc[0].ct = proc[0].at + proc[0].bt;
    proc[0].tat = proc[0].ct - proc[0].at;
    proc[0].wt = proc[0].tat - proc[0].bt;

    for (i = 1; i < n; i++) {
        if (proc[i].at > proc[i-1].ct) {
            proc[i].ct = proc[i].at + proc[i].bt; // CPU idle
        } else {
            proc[i].ct = proc[i-1].ct + proc[i].bt;
        }
        proc[i].tat = proc[i].ct - proc[i].at;
        proc[i].wt = proc[i].tat - proc[i].bt;
    }
}

// Square-box style Gantt Chart
void printGanttChart(struct Process proc[], int n) {
    int i;
    printf("\nGantt Chart :\n\n");

    // Top border
    for (i = 0; i < n; i++) {
        printf("+-----");
    }
    printf("+\n");

    // Process IDs inside squares
    for (i = 0; i < n; i++) {
        printf("| P%-2d ", proc[i].pid);
    }
    printf("|\n");

    // Bottom border
    for (i = 0; i < n; i++) {
        printf("+-----");
    }
    printf("+\n");

    // Timeline
    printf("%d", proc[0].at);
    for (i = 0; i < n; i++) {
        printf(" %-5d", proc[i].ct);
    }
    printf("\n");
}

void findAvgTime(struct Process proc[], int n) {
    int total_wt = 0, total_tat = 0;
    int i;

    printf("\nProcesses  AT\t BT\t CT\t TAT \t WT\n");
    for (i = 0; i < n; i++) {
        printf("P%-2d\t   %d\t  %d\t  %d\t  %d\t  %d\n", proc[i].pid, proc[i].at, proc[i].bt, proc[i].ct, proc[i].tat, proc[i].wt);
        total_wt += proc[i].wt;
        total_tat += proc[i].tat;
    }

    printf("\nAverage Waiting Time = %.2f", (float)total_wt / n);
    printf("\nAverage Turnaround Time = %.2f\n", (float)total_tat / n);

    printGanttChart(proc, n);
}

int main() {
    int n, i;
    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct Process proc[n];
    for (i = 0; i < n; i++) {
        printf("Enter arrival time and burst time for process %d: ", i + 1);
        scanf("%d %d", &proc[i].at, &proc[i].bt);
        proc[i].pid = i + 1;
    }

    sortByArrival(proc, n);
    findTimes(proc, n);
    findAvgTime(proc, n);

    return 0;
}
/*
output:-

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc fcfs_schedule.c

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./a.out

Enter the number of processes: 5
Enter arrival time and burst time for process 1: 7 5 
Enter arrival time and burst time for process 2: 3 4 
Enter arrival time and burst time for process 3: 10 3
Enter arrival time and burst time for process 4: 0 8 
Enter arrival time and burst time for process 5: 12 6

Processes  AT	 BT	 CT	 TAT 	 WT
P4 	   0	  8	  8	  8	  0
P2 	   3	  4	  12	  9	  5
P1 	   7	  5	  17	  10	  5
P3 	   10	  3	  20	  10	  7
P5 	   12	  6	  26	  14	  8

Average Waiting Time = 5.00
Average Turnaround Time = 10.20

Gantt Chart :

+-----+-----+-----+-----+-----+
| P4  | P2  | P1  | P3  | P5  |
+-----+-----+-----+-----+-----+
0 8     12    17    20    26   
*/

