// server.c
#include <sys/shm.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>

#define SIZE 400
#define DATA_NOT_FILLED -1
#define DATA_FILLED 0
#define DATA_READ_CLIENT 1

typedef struct data {
    int status;
    char buff[100];
} datal;

int main() {
    int key, shmid, i = 0;
    char ch;
    datal *shm_ptr;

    key = ftok(".", 'A');
    if (key == -1) {
        perror("ftok");
        exit(1);
    }

    shmid = shmget(key, SIZE, IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget");
        exit(1);
    }
    printf("Shared memory created with id: %d\n", shmid);

    shm_ptr = (datal *)shmat(shmid, NULL, 0);
    if (shm_ptr == (void *)-1) {
        perror("shmat");
        exit(1);
    }

    shm_ptr->status = DATA_NOT_FILLED;

    printf("Enter the text ending with '#':\n");
    i = 0;
    while ((ch = getchar()) != '#' && i < sizeof(shm_ptr->buff) - 1) {
        shm_ptr->buff[i++] = ch;
    }
    shm_ptr->buff[i] = '\0';

    shm_ptr->status = DATA_FILLED;
    printf("Data written to shared memory: %s\n", shm_ptr->buff);

    while (shm_ptr->status != DATA_READ_CLIENT) {
        printf("Waiting for client to read the data...\n");
        sleep(1);
    }

    shmdt(shm_ptr);
    shmctl(shmid, IPC_RMID, 0);
    printf("Shared memory removed. Server exiting.\n");
    return 0;
}
/*
Output:-

ayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc server.c -o Server
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc client.c -o Client
gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./Server
Shared memory created with id: 753673
Enter the text ending with '#':
gaYU#
Data written to shared memory: gaYU
Waiting for client to read the data...
Waiting for client to read the data...
Shared memory removed. Server exiting.
in 2 nd window of terminal 
ayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./Client
Shared memory ID found: 753673
Shared memory attached successfully.
Data read from shared memory: gaYU
Client detached shared memory and exiting.

*/

