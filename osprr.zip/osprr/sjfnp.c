#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

struct Process {
    int pid; // Process ID
    int at;  // Arrival Time
    int bt;  // Burst Time
    int ct;  // Completion Time
    int tat; // Turnaround Time
    int wt;  // Waiting Time
};

// To store execution order
struct Gantt {
    int pid;
    int start;
    int end;
};

void sortByArrival(struct Process proc[], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (proc[i].at > proc[j].at) {
                struct Process temp = proc[i];
                proc[i] = proc[j];
                proc[j] = temp;
            } else if (proc[i].at == proc[j].at && proc[i].bt > proc[j].bt) {
                struct Process temp = proc[i];
                proc[i] = proc[j];
                proc[j] = temp;
            }
        }
    }
}

int findTimes(struct Process proc[], int n, struct Gantt gantt[]) {
    int time = 0, completed = 0, gIndex = 0;
    int done[100] = {0}; // Done array to track completed processes

    while (completed < n) {
        int idx = -1, minBT = INT_MAX;

        // Find process with min burst among arrived processes
        for (int i = 0; i < n; i++) {
            if (!done[i] && proc[i].at <= time) {
                if (proc[i].bt < minBT) {
                    minBT = proc[i].bt;
                    idx = i;
                }
            }
        }

        if (idx == -1) {
            time++; // CPU idle
        } else {
            gantt[gIndex].pid = proc[idx].pid;
            gantt[gIndex].start = time;
            time += proc[idx].bt;
            proc[idx].ct = time;
            proc[idx].tat = proc[idx].ct - proc[idx].at;
            proc[idx].wt = proc[idx].tat - proc[idx].bt;
            done[idx] = 1;
            gantt[gIndex].end = time;
            gIndex++;
            completed++;
        }
    }
    return n; // number of executed processes (same as n)
}

void display(struct Process proc[], int n) {
    int total_wt = 0, total_tat = 0;

    printf("\nProcesses\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t\t%d\t%d\t%d\t%d\t%d\n", proc[i].pid, proc[i].at, proc[i].bt,
               proc[i].ct, proc[i].tat, proc[i].wt);

        total_wt += proc[i].wt;
        total_tat += proc[i].tat;
    }

    printf("\nAverage Waiting Time = %.2f\n", (float)total_wt / n);
    printf("Average Turnaround Time = %.2f\n", (float)total_tat / n);
}

void printGanttChart(struct Gantt gantt[], int n) {
    printf("\nGantt Chart :\n\n");

    // Top border
    for (int i = 0; i < n; i++) printf("+-----");
    printf("+\n");

    // Process IDs
    for (int i = 0; i < n; i++) {
        printf("| P%-2d ", gantt[i].pid);
    }
    printf("|\n");

    // Bottom border
    for (int i = 0; i < n; i++) printf("+-----");
    printf("+\n");

    // Timeline
    printf("%d", gantt[0].start);
    for (int i = 0; i < n; i++) {
        printf("     %d", gantt[i].end);
    }
    printf("\n");
}

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process *proc = (struct Process *)malloc(n * sizeof(struct Process));
    struct Gantt *gantt = (struct Gantt *)malloc(n * sizeof(struct Gantt));

    for (int i = 0; i < n; i++) {
        printf("Enter Arrival Time and Burst Time for Process %d: ", i + 1);
        scanf("%d %d", &proc[i].at, &proc[i].bt);
        proc[i].pid = i + 1;
    }

    sortByArrival(proc, n);
    int gCount = findTimes(proc, n, gantt);

    display(proc, n);
    printGanttChart(gantt, gCount);

    free(proc);
    free(gantt);

    return 0;
}
/*
output:-

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc sjfnp.c

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./a.out

Enter number of processes: 5
Enter Arrival Time and Burst Time for Process 1: 7 5
Enter Arrival Time and Burst Time for Process 2: 3 4
Enter Arrival Time and Burst Time for Process 3: 10 3
Enter Arrival Time and Burst Time for Process 4: 0 8 
Enter Arrival Time and Burst Time for Process 5: 12 6

Processes	AT	BT	CT	TAT	WT
P4		0	8	8	8	0
P2		3	4	12	9	5
P1		7	5	20	13	8
P3		10	3	15	5	2
P5		12	6	26	14	8

Average Waiting Time = 4.60
Average Turnaround Time = 9.80

Gantt Chart :

+-----+-----+-----+-----+-----+
| P4  | P2  | P3  | P1  | P5  |
+-----+-----+-----+-----+-----+
0     8     12     15     20     26
*/
