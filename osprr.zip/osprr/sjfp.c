#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

struct Process {
    int pid;  // Process ID
    int at;   // Arrival Time
    int bt;   // Burst Time
    int ct;   // Completion Time
    int tat;  // Turnaround Time
    int wt;   // Waiting Time
    int rt;   // Remaining Time
};

// Slot for Gantt chart
struct Slot {
    int pid;   // process id (-1 = idle)
    int start; // start time
    int end;   // end time
};

// Function to calculate times and prepare Gantt chart
int findTimes(struct Process proc[], int n, struct Slot slots[]) {
    int time = 0, completed = 0;
    int prev = -2; // previous process ID
    int k = 0;     // slot index

    while (completed < n) {
        int idx = -1, minRT = INT_MAX;

        // Select process with min remaining time among arrived
        for (int i = 0; i < n; i++) {
            if (proc[i].at <= time && proc[i].rt > 0) {
                if (proc[i].rt < minRT) {
                    minRT = proc[i].rt;
                    idx = i;
                } else if (proc[i].rt == minRT && proc[i].at < proc[idx].at) {
                    idx = i;
                }
            }
        }

        if (idx == -1) { // CPU idle
            if (prev != -1) { // new idle slot
                slots[k].end = time;
                k++;
            }
            slots[k].pid = -1; // idle
            slots[k].start = time;
            prev = -1;
            time++;
        } else {
            if (prev != proc[idx].pid) { // context switch
                if (prev != -2) {
                    slots[k].end = time; // close previous slot
                    k++;
                }
                slots[k].pid = proc[idx].pid;
                slots[k].start = time;
                prev = proc[idx].pid;
            }
            proc[idx].rt--;
            time++;

            if (proc[idx].rt == 0) {
                proc[idx].ct = time;
                proc[idx].tat = proc[idx].ct - proc[idx].at;
                proc[idx].wt = proc[idx].tat - proc[idx].bt;
                completed++;
            }
        }
    }

    slots[k].end = time; // close last slot
    k++;
    return k; // return number of slots
}

// Display process table
void display(struct Process proc[], int n) {
    int total_wt = 0, total_tat = 0;

    printf("\nProcesses\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t\t%d\t%d\t%d\t%d\t%d\n", proc[i].pid, proc[i].at, proc[i].bt, proc[i].ct, proc[i].tat, proc[i].wt);

        total_wt += proc[i].wt;
        total_tat += proc[i].tat;
    }

    printf("\nAverage Waiting Time = %.2f", (float)total_wt / n);
    printf("\nAverage Turnaround Time = %.2f\n", (float)total_tat / n);
}

// Print Gantt Chart (square style)
void printGanttChart(struct Slot slots[], int k) {
    printf("\nGantt Chart (SJF Preemptive):\n\n");

    for (int i = 0; i < k; i++) printf("+-----");
    printf("+\n");

    for (int i = 0; i < k; i++) {
        if (slots[i].pid == -1)
            printf("| IDLE");
        else
            printf("| P%-2d ", slots[i].pid);
    }
    printf("|\n");

    for (int i = 0; i < k; i++) printf("+-----");
    printf("+\n");

    printf("%d", slots[0].start);
    for (int i = 0; i < k; i++) printf(" %-5d", slots[i].end);
    printf("\n");
}

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process proc[n];
    for (int i = 0; i < n; i++) {
        printf("Enter Arrival Time and Burst Time for Process %d: ", i + 1);
        scanf("%d %d", &proc[i].at, &proc[i].bt);
        proc[i].pid = i + 1;
        proc[i].rt = proc[i].bt; // Initialize remaining time
    }

    struct Slot slots[200];
    int k = findTimes(proc, n, slots);
    display(proc, n);
    printGanttChart(slots, k);
    return 0;
}
/*
output:-

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ gcc sjfp.c

gayulap@gayulap-VirtualBox:~/Desktop/ospr$ ./a.out

Enter number of processes: 4
Enter Arrival Time and Burst Time for Process 1: 0 3
Enter Arrival Time and Burst Time for Process 2: 1 6
Enter Arrival Time and Burst Time for Process 3: 4 4 
Enter Arrival Time and Burst Time for Process 4: 6 2

Processes	AT	BT	CT	TAT	WT
P1		0	3	3	3	0
P2		1	6	15	14	8
P3		4	4	8	4	0
P4		6	2	10	4	2

Average Waiting Time = 2.50
Average Turnaround Time = 6.25

Gantt Chart (SJF Preemptive):

+-----+-----+-----+-----+-----+
| P1  | P2  | P3  | P4  | P2  |
+-----+-----+-----+-----+-----+
0 3     4     8     10    15   

*/

